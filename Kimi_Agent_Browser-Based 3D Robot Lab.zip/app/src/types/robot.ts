export type Vec3 = [number, number, number]
export type ObjectId = 'cube' | 'sphere' | 'cylinder'

export type Keyframe = {
  id: string
  name: string
  time: number
  joints: number[]
  gripper: number
}

export type ObjectPositions = Record<ObjectId, Vec3>

export type Telemetry = {
  tip: Vec3
  fps: number
  held: ObjectId | null
}

export const JOINTS = [
  { label: 'Base rotation', short: 'J1', min: -180, max: 180, axis: 'Y' },
  { label: 'Shoulder', short: 'J2', min: -110, max: 45, axis: 'Z' },
  { label: 'Elbow', short: 'J3', min: -20, max: 135, axis: 'Z' },
  { label: 'Wrist pitch', short: 'J4', min: -180, max: 180, axis: 'Z' },
  { label: 'Wrist roll', short: 'J5', min: -180, max: 180, axis: 'Y' },
  { label: 'Tool rotation', short: 'J6', min: -180, max: 180, axis: 'Y' },
]

export const HOME_JOINTS = [0, -55, 90, -35, 0, 0]
export const INITIAL_OBJECTS: ObjectPositions = {
  cube: [0.45, 1.2, 0.35],
  sphere: [1.25, 1.22, -0.65],
  cylinder: [1.45, 1.25, 0.75],
}

export const OBJECT_META: Record<ObjectId, { name: string; code: string; color: string; height: number }> = {
  cube: { name: 'Calibration cube', code: 'A–01', color: '#f0a654', height: 0.6 },
  sphere: { name: 'Test sphere', code: 'B–02', color: '#61d6c7', height: 0.64 },
  cylinder: { name: 'Aluminium blank', code: 'C–03', color: '#a8b6c2', height: 0.7 },
}

export const PICK_AND_PLACE: Keyframe[] = [
  { id: 'home', name: 'Home', time: 0, joints: HOME_JOINTS, gripper: 85 },
  { id: 'approach', name: 'Approach', time: 3.5, joints: [-8.5, -110, 64.3, 53.5, 0, 0], gripper: 85 },
  { id: 'grasp', name: 'Grasp', time: 6, joints: [-8.5, -110, 64.3, 53.5, 0, 0], gripper: 18 },
  { id: 'lift', name: 'Lift', time: 8.5, joints: [-8.5, -75, 55, 20, 0, 0], gripper: 18 },
  { id: 'place', name: 'Place', time: 12, joints: [35, -100, 70, 30, 0, 0], gripper: 85 },
]
