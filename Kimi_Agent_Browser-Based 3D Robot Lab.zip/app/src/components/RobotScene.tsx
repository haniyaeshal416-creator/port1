import { useEffect, useRef } from 'react'
import * as THREE from 'three'
import { OrbitControls } from 'three/addons/controls/OrbitControls.js'
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js'
import { OBJECT_META, type ObjectId, type ObjectPositions, type Telemetry, type Vec3 } from '../types/robot'

type RobotSceneProps = {
  joints: number[]
  gripper: number
  objectPositions: ObjectPositions
  selectedObject: ObjectId
  showGrid: boolean
  showColliders: boolean
  view: 'perspective' | 'front' | 'top'
  resetViewToken: number
  onSelectObject: (id: ObjectId) => void
  onTelemetry: (data: Telemetry) => void
  onCollisions: (names: string[]) => void
  onObjectRelease: (id: ObjectId, position: Vec3) => void
}

const TABLE_TOP = 0.9
const ROBOT_ORIGIN = new THREE.Vector3(-1.9, TABLE_TOP, 0)
const UPPER_LENGTH = 1.55
const FOREARM_LENGTH = 1.25
const DEG = Math.PI / 180

function material(color: string, metalness = 0.65, roughness = 0.32) {
  return new THREE.MeshStandardMaterial({ color, metalness, roughness })
}

function addMesh(
  parent: THREE.Object3D,
  geometry: THREE.BufferGeometry,
  mat: THREE.Material,
  position: Vec3 = [0, 0, 0],
) {
  const mesh = new THREE.Mesh(geometry, mat)
  mesh.position.set(...position)
  mesh.castShadow = true
  mesh.receiveShadow = true
  parent.add(mesh)
  return mesh
}

function addCylinder(parent: THREE.Object3D, radius: number, depth: number, mat: THREE.Material, position: Vec3, axis = 'y') {
  const mesh = addMesh(parent, new THREE.CylinderGeometry(radius, radius, depth, 32), mat, position)
  if (axis === 'z') mesh.rotation.x = Math.PI / 2
  if (axis === 'x') mesh.rotation.z = Math.PI / 2
  return mesh
}

function makeLabel(text: string, color = '#d8ff62') {
  const canvas = document.createElement('canvas')
  canvas.width = 512
  canvas.height = 96
  const ctx = canvas.getContext('2d')!
  ctx.clearRect(0, 0, canvas.width, canvas.height)
  ctx.fillStyle = 'rgba(11, 16, 18, .88)'
  ctx.fillRect(2, 2, 508, 92)
  ctx.strokeStyle = 'rgba(190, 211, 209, .3)'
  ctx.lineWidth = 2
  ctx.strokeRect(2, 2, 508, 92)
  ctx.font = '500 35px monospace'
  ctx.textAlign = 'center'
  ctx.textBaseline = 'middle'
  ctx.fillStyle = color
  ctx.fillText(text, 256, 50)
  const texture = new THREE.CanvasTexture(canvas)
  texture.colorSpace = THREE.SRGBColorSpace
  const sprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: texture, transparent: true, depthWrite: false }))
  sprite.scale.set(0.8, 0.15, 1)
  return sprite
}

export default function RobotScene(props: RobotSceneProps) {
  const mountRef = useRef<HTMLDivElement>(null)
  const propsRef = useRef(props)
  propsRef.current = props

  useEffect(() => {
    const mount = mountRef.current
    if (!mount) return

    const scene = new THREE.Scene()
    scene.background = new THREE.Color('#11181b')
    scene.fog = new THREE.FogExp2('#11181b', 0.027)

    const camera = new THREE.PerspectiveCamera(38, 1, 0.1, 100)
    camera.position.set(7.6, 5.6, 8.6)
    const renderer = new THREE.WebGLRenderer({ antialias: false, powerPreference: 'high-performance' })
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.25))
    renderer.shadowMap.enabled = true
    renderer.shadowMap.type = THREE.PCFShadowMap
    renderer.outputColorSpace = THREE.SRGBColorSpace
    renderer.toneMapping = THREE.ACESFilmicToneMapping
    renderer.toneMappingExposure = 1.12
    mount.appendChild(renderer.domElement)
    renderer.domElement.setAttribute('aria-label', 'Interactive 3D robotic arm laboratory. Use the joint sliders as keyboard-accessible controls.')
    renderer.domElement.setAttribute('role', 'img')

    const pmrem = new THREE.PMREMGenerator(renderer)
    const environment = new RoomEnvironment()
    const envTarget = pmrem.fromScene(environment, 0.04)
    scene.environment = envTarget.texture
    environment.dispose()
    pmrem.dispose()

    const controls = new OrbitControls(camera, renderer.domElement)
    controls.target.set(0, 1.35, 0)
    controls.enableDamping = true
    controls.dampingFactor = 0.07
    controls.minDistance = 4
    controls.maxDistance = 19
    controls.maxPolarAngle = Math.PI * 0.49
    controls.update()

    scene.add(new THREE.HemisphereLight('#d5e8ec', '#26302d', 1.55))
    const keyLight = new THREE.DirectionalLight('#f3f6e9', 3.4)
    keyLight.position.set(3, 8, 5)
    keyLight.castShadow = true
    keyLight.shadow.mapSize.set(1024, 1024)
    keyLight.shadow.camera.left = -7
    keyLight.shadow.camera.right = 7
    keyLight.shadow.camera.top = 7
    keyLight.shadow.camera.bottom = -7
    keyLight.shadow.bias = -0.00025
    scene.add(keyLight)
    const rimLight = new THREE.DirectionalLight('#6bbbc2', 2.2)
    rimLight.position.set(-5, 4, -5)
    scene.add(rimLight)
    const taskLight = new THREE.PointLight('#d8ff62', 8, 5, 2)
    taskLight.position.set(-1.7, 4.5, 0)
    scene.add(taskLight)

    const steel = material('#89969a', 0.85, 0.28)
    const darkSteel = material('#253036', 0.82, 0.3)
    const black = material('#11191c', 0.55, 0.42)
    const armPaint = material('#c5ccc5', 0.68, 0.27)
    const accent = material('#d4f45c', 0.4, 0.32)
    const orange = material('#d98c38', 0.55, 0.36)

    // Laboratory architecture and work cell.
    const floor = addMesh(scene, new THREE.PlaneGeometry(40, 40), material('#151d20', 0.35, 0.72), [0, 0, 0])
    floor.rotation.x = -Math.PI / 2
    floor.castShadow = false
    const grid = new THREE.GridHelper(30, 60, '#35464a', '#243135')
    grid.position.y = 0.006
    scene.add(grid)

    const bench = new THREE.Group()
    scene.add(bench)
    addMesh(bench, new THREE.BoxGeometry(7.8, 0.24, 4.8), darkSteel, [0, 0.78, 0])
    addMesh(bench, new THREE.BoxGeometry(7.65, 0.055, 4.65), material('#364247', 0.8, 0.4), [0, 0.925, 0])
    for (const x of [-3.35, 3.35]) {
      for (const z of [-1.85, 1.85]) addMesh(bench, new THREE.BoxGeometry(0.18, 0.7, 0.18), black, [x, 0.35, z])
    }
    const benchGrid = new THREE.GridHelper(7.5, 30, '#536367', '#435256')
    benchGrid.scale.z = 0.6
    benchGrid.position.y = 0.958
    bench.add(benchGrid)

    const stripeMat = new THREE.MeshBasicMaterial({ color: '#d4f45c', transparent: true, opacity: 0.52 })
    const stripe = addMesh(scene, new THREE.RingGeometry(2.55, 2.59, 80, 1, 0, Math.PI * 1.72), stripeMat, [-1.25, 0.963, 0])
    stripe.rotation.x = -Math.PI / 2
    stripe.castShadow = false

    const rearWall = addMesh(scene, new THREE.BoxGeometry(14, 5.5, 0.18), material('#1a2428', 0.45, 0.65), [0, 2.65, -5.2])
    rearWall.castShadow = false
    for (const x of [-4.8, -1.6, 1.6, 4.8]) {
      addMesh(scene, new THREE.BoxGeometry(0.055, 4.6, 0.06), steel, [x, 2.7, -5.05])
    }
    addMesh(scene, new THREE.BoxGeometry(12.8, 0.06, 0.08), steel, [0, 3.65, -5.02])
    const wallLabel = makeLabel('LAB 01', '#b9c8c9')
    wallLabel.position.set(0, 3.95, -4.98)
    wallLabel.scale.set(4.1, 0.77, 1)
    scene.add(wallLabel)
    for (const x of [-4, 0, 4]) {
      const lightPanel = addMesh(scene, new THREE.BoxGeometry(2.4, 0.06, 0.32), new THREE.MeshBasicMaterial({ color: '#b7d6d6' }), [x, 5.1, -1.8])
      lightPanel.castShadow = false
    }

    const bin = new THREE.Group()
    bin.position.set(2.85, TABLE_TOP, -0.85)
    scene.add(bin)
    addMesh(bin, new THREE.BoxGeometry(1.15, 0.12, 1.25), black, [0, 0.06, 0])
    for (const x of [-0.54, 0.54]) addMesh(bin, new THREE.BoxGeometry(0.07, 0.5, 1.25), darkSteel, [x, 0.3, 0])
    for (const z of [-0.59, 0.59]) addMesh(bin, new THREE.BoxGeometry(1.15, 0.5, 0.07), darkSteel, [0, 0.3, z])
    const binLabel = makeLabel('PARTS / 04', '#9aadb0')
    binLabel.position.set(0, 0.75, 0)
    bin.add(binLabel)

    const safetyPost = new THREE.Group()
    safetyPost.position.set(0.05, TABLE_TOP, -1.65)
    scene.add(safetyPost)
    addCylinder(safetyPost, 0.19, 0.08, black, [0, 0.04, 0])
    addCylinder(safetyPost, 0.055, 0.9, orange, [0, 0.5, 0])
    addCylinder(safetyPost, 0.1, 0.13, black, [0, 0.94, 0])
    const beacon = addCylinder(safetyPost, 0.075, 0.12, new THREE.MeshStandardMaterial({ color: '#d4f45c', emissive: '#7f9c28', emissiveIntensity: 1.6 }), [0, 1.06, 0])
    beacon.castShadow = false

    // Six-axis robot. Every articulation is a separate transform in the chain.
    const robot = new THREE.Group()
    robot.position.copy(ROBOT_ORIGIN)
    scene.add(robot)
    addCylinder(robot, 0.68, 0.16, black, [0, 0.08, 0])
    addCylinder(robot, 0.57, 0.62, darkSteel, [0, 0.35, 0])
    addCylinder(robot, 0.48, 0.1, accent, [0, 0.73, 0])
    for (let i = 0; i < 8; i++) {
      const a = (i / 8) * Math.PI * 2
      addCylinder(robot, 0.035, 0.035, steel, [Math.cos(a) * 0.54, 0.17, Math.sin(a) * 0.54])
    }

    const baseYaw = new THREE.Group()
    baseYaw.position.y = 0.78
    robot.add(baseYaw)
    addCylinder(baseYaw, 0.43, 0.25, armPaint, [0, 0.1, 0])
    const shoulder = new THREE.Group()
    shoulder.position.y = 0.22
    baseYaw.add(shoulder)
    addCylinder(shoulder, 0.38, 0.72, darkSteel, [0, 0, 0], 'z')
    addCylinder(shoulder, 0.28, 0.76, accent, [0, 0, 0], 'z')
    const upper = addMesh(shoulder, new THREE.BoxGeometry(0.46, UPPER_LENGTH, 0.54), armPaint.clone(), [0, UPPER_LENGTH / 2, 0])
    addMesh(shoulder, new THREE.BoxGeometry(0.48, 0.6, 0.565), darkSteel, [0, 0.67, 0])
    addMesh(shoulder, new THREE.BoxGeometry(0.485, 0.1, 0.575), accent, [0, 1.14, 0])
    const upperCable = addMesh(shoulder, new THREE.BoxGeometry(0.1, 1.05, 0.09), black, [-0.28, 0.86, 0])
    upperCable.rotation.z = -0.05

    const elbow = new THREE.Group()
    elbow.position.y = UPPER_LENGTH
    shoulder.add(elbow)
    addCylinder(elbow, 0.32, 0.68, darkSteel, [0, 0, 0], 'z')
    addCylinder(elbow, 0.22, 0.72, steel, [0, 0, 0], 'z')
    const forearm = addMesh(elbow, new THREE.BoxGeometry(0.36, FOREARM_LENGTH, 0.44), armPaint.clone(), [0, FOREARM_LENGTH / 2, 0])
    addMesh(elbow, new THREE.BoxGeometry(0.38, 0.36, 0.46), darkSteel, [0, 0.75, 0])
    addMesh(elbow, new THREE.BoxGeometry(0.385, 0.07, 0.47), accent, [0, 0.98, 0])

    const wristPitch = new THREE.Group()
    wristPitch.position.y = FOREARM_LENGTH
    elbow.add(wristPitch)
    addCylinder(wristPitch, 0.24, 0.52, darkSteel, [0, 0, 0], 'z')
    const wristRoll = new THREE.Group()
    wristPitch.add(wristRoll)
    const wrist = addCylinder(wristRoll, 0.2, 0.38, steel.clone(), [0, -0.17, 0])
    const toolRotation = new THREE.Group()
    toolRotation.position.y = -0.33
    wristRoll.add(toolRotation)
    addCylinder(toolRotation, 0.23, 0.12, accent, [0, 0, 0])
    addMesh(toolRotation, new THREE.BoxGeometry(0.64, 0.22, 0.38), darkSteel, [0, -0.15, 0])
    const fingerLeft = new THREE.Group()
    const fingerRight = new THREE.Group()
    toolRotation.add(fingerLeft, fingerRight)
    addMesh(fingerLeft, new THREE.BoxGeometry(0.095, 0.48, 0.22), steel, [0, -0.38, 0])
    addMesh(fingerRight, new THREE.BoxGeometry(0.095, 0.48, 0.22), steel, [0, -0.38, 0])
    addMesh(fingerLeft, new THREE.BoxGeometry(0.12, 0.11, 0.26), black, [0.035, -0.62, 0])
    addMesh(fingerRight, new THREE.BoxGeometry(0.12, 0.11, 0.26), black, [-0.035, -0.62, 0])
    const toolTip = new THREE.Object3D()
    toolTip.position.y = -0.69
    toolRotation.add(toolTip)

    const robotLabel = makeLabel('KR–6  /  AXIS READY')
    robotLabel.position.set(0, 0.34, 0.62)
    robotLabel.scale.set(0.9, 0.17, 1)
    robot.add(robotLabel)

    const objectGroups = {} as Record<ObjectId, THREE.Group>
    const objectMaterials = {} as Record<ObjectId, THREE.MeshStandardMaterial>
    const pickMeshes: THREE.Object3D[] = []
    const selectionRings = {} as Record<ObjectId, THREE.Mesh>
    const makeObject = (id: ObjectId, geometry: THREE.BufferGeometry, color: string) => {
      const group = new THREE.Group()
      group.userData.objectId = id
      const mat = new THREE.MeshStandardMaterial({ color, metalness: id === 'sphere' ? 0.25 : 0.72, roughness: 0.28 })
      const body = addMesh(group, geometry, mat)
      body.userData.objectId = id
      objectMaterials[id] = mat
      objectGroups[id] = group
      pickMeshes.push(body)
      const ring = new THREE.Mesh(
        new THREE.RingGeometry(0.39, 0.43, 40),
        new THREE.MeshBasicMaterial({ color: '#d4f45c', transparent: true, opacity: 0.9, side: THREE.DoubleSide }),
      )
      ring.rotation.x = -Math.PI / 2
      ring.position.y = -OBJECT_META[id].height / 2 + 0.012
      group.add(ring)
      selectionRings[id] = ring
      const label = makeLabel(OBJECT_META[id].code, OBJECT_META[id].color)
      label.position.y = OBJECT_META[id].height / 2 + 0.34
      group.add(label)
      scene.add(group)
    }
    makeObject('cube', new THREE.BoxGeometry(0.6, 0.6, 0.6), OBJECT_META.cube.color)
    makeObject('sphere', new THREE.SphereGeometry(0.32, 36, 24), OBJECT_META.sphere.color)
    makeObject('cylinder', new THREE.CylinderGeometry(0.29, 0.29, 0.7, 36), OBJECT_META.cylinder.color)

    const colliderLinks = [
      { mesh: upper, name: 'Upper arm' },
      { mesh: forearm, name: 'Forearm' },
      { mesh: wrist, name: 'Wrist' },
    ]
    const collisionEntries = [
      { object: bin, name: 'Parts bin' },
      { object: safetyPost, name: 'Safety beacon' },
      { object: objectGroups.cube, name: 'Calibration cube' },
      { object: objectGroups.sphere, name: 'Test sphere' },
      { object: objectGroups.cylinder, name: 'Aluminium blank' },
    ]
    const boundsHelpers: THREE.Box3Helper[] = []
    for (let i = 0; i < colliderLinks.length + collisionEntries.length; i++) {
      const helper = new THREE.Box3Helper(new THREE.Box3(), new THREE.Color('#59d9c6'))
      helper.visible = false
      scene.add(helper)
      boundsHelpers.push(helper)
    }

    const raycaster = new THREE.Raycaster()
    const pointer = new THREE.Vector2()
    let pointerStart = { x: 0, y: 0 }
    const onPointerDown = (event: PointerEvent) => {
      pointerStart = { x: event.clientX, y: event.clientY }
    }
    const onPointerUp = (event: PointerEvent) => {
      if (Math.hypot(event.clientX - pointerStart.x, event.clientY - pointerStart.y) > 5) return
      const rect = renderer.domElement.getBoundingClientRect()
      pointer.set(((event.clientX - rect.left) / rect.width) * 2 - 1, -((event.clientY - rect.top) / rect.height) * 2 + 1)
      raycaster.setFromCamera(pointer, camera)
      const hit = raycaster.intersectObjects(pickMeshes, false)[0]
      if (hit) propsRef.current.onSelectObject(hit.object.userData.objectId as ObjectId)
    }
    renderer.domElement.addEventListener('pointerdown', onPointerDown)
    renderer.domElement.addEventListener('pointerup', onPointerUp)

    const resize = () => {
      const width = mount.clientWidth
      const height = mount.clientHeight
      if (!width || !height) return
      renderer.setSize(width, height, false)
      camera.aspect = width / height
      camera.updateProjectionMatrix()
    }
    const observer = new ResizeObserver(resize)
    observer.observe(mount)
    resize()

    let animationId = 0
    let previousTime = performance.now()
    let lastRender = 0
    let telemetryTime = performance.now()
    let frames = 0
    let heldObject: ObjectId | null = null
    let previousGrip = propsRef.current.gripper
    let previousView = propsRef.current.view
    let previousReset = propsRef.current.resetViewToken
    let previousCollisionKey = ''
    let collisionStopped = false
    const tipPosition = new THREE.Vector3()
    const tempPosition = new THREE.Vector3()

    const releaseHeld = () => {
      if (!heldObject) return
      const id = heldObject
      const group = objectGroups[id]
      group.getWorldPosition(tempPosition)
      group.position.set(tempPosition.x, TABLE_TOP + OBJECT_META[id].height / 2 + 0.055, tempPosition.z)
      propsRef.current.onObjectRelease(id, [group.position.x, group.position.y, group.position.z])
      heldObject = null
    }

    const animate = (now: number) => {
      animationId = requestAnimationFrame(animate)
      if (now - lastRender < 1000 / 30) return
      lastRender = now
      const delta = Math.min((now - previousTime) / 1000, 0.05)
      previousTime = now
      const current = propsRef.current

      if (current.view !== previousView || current.resetViewToken !== previousReset) {
        const positions = {
          perspective: new THREE.Vector3(7.6, 5.6, 8.6),
          front: new THREE.Vector3(0, 3.1, 11.8),
          top: new THREE.Vector3(0.01, 12.8, 0.01),
        }
        camera.position.copy(positions[current.view])
        controls.target.set(0, 1.25, 0)
        controls.update()
        previousView = current.view
        previousReset = current.resetViewToken
      }

      baseYaw.rotation.y = current.joints[0] * DEG
      shoulder.rotation.z = current.joints[1] * DEG
      elbow.rotation.z = current.joints[2] * DEG
      wristPitch.rotation.z = current.joints[3] * DEG
      wristRoll.rotation.y = current.joints[4] * DEG
      toolRotation.rotation.y = current.joints[5] * DEG
      const fingerGap = 0.14 + (current.gripper / 100) * 0.22
      fingerLeft.position.set(-fingerGap, -0.18, 0)
      fingerRight.position.set(fingerGap, -0.18, 0)

      grid.visible = current.showGrid
      benchGrid.visible = current.showGrid
      for (const id of Object.keys(objectGroups) as ObjectId[]) {
        const group = objectGroups[id]
        if (heldObject !== id) group.position.set(...current.objectPositions[id])
        selectionRings[id].visible = current.selectedObject === id
        objectMaterials[id].emissive.set(current.selectedObject === id ? OBJECT_META[id].color : '#000000')
        objectMaterials[id].emissiveIntensity = current.selectedObject === id ? 0.12 : 0
      }

      robot.updateMatrixWorld(true)
      toolTip.getWorldPosition(tipPosition)

      if (previousGrip > 42 && current.gripper <= 42 && !heldObject) {
        let nearest: ObjectId | null = null
        let nearestDistance = 0.72
        for (const id of Object.keys(objectGroups) as ObjectId[]) {
          const distance = objectGroups[id].position.distanceTo(tipPosition)
          if (distance < nearestDistance) {
            nearest = id
            nearestDistance = distance
          }
        }
        if (nearest) heldObject = nearest
      }
      if (previousGrip < 62 && current.gripper >= 62 && heldObject) releaseHeld()
      previousGrip = current.gripper

      if (heldObject) {
        objectGroups[heldObject].position.copy(tipPosition)
        objectGroups[heldObject].position.y -= 0.08
        objectGroups[heldObject].rotation.y += delta * 0.18
      }

      const collisions: string[] = []
      const armBoxes: THREE.Box3[] = []
      scene.updateMatrixWorld(true)
      colliderLinks.forEach(({ mesh, name }) => {
        const box = new THREE.Box3().setFromObject(mesh).expandByScalar(-0.025)
        armBoxes.push(box)
        if (box.min.y < TABLE_TOP + 0.015) collisions.push(`${name} / work surface`)
      })
      collisionEntries.forEach(({ object, name }) => {
        const id = object.userData.objectId as ObjectId | undefined
        if (id && (heldObject === id || (current.selectedObject === id && current.gripper > 42))) return
        const other = new THREE.Box3().setFromObject(object).expandByScalar(-0.035)
        if (armBoxes.some((box) => box.intersectsBox(other))) collisions.push(name)
      })
      const uniqueCollisions = [...new Set(collisions)]
      const collisionKey = uniqueCollisions.join('|')
      if (collisionKey !== previousCollisionKey) {
        previousCollisionKey = collisionKey
        current.onCollisions(uniqueCollisions)
        collisionStopped = false
      }
      const hasCollision = uniqueCollisions.length > 0
      colliderLinks.forEach(({ mesh }) => {
        const mat = mesh.material as THREE.MeshStandardMaterial
        mat.emissive.set(hasCollision ? '#8f231c' : '#000000')
        mat.emissiveIntensity = hasCollision ? 0.8 : 0
      })

      let helperIndex = 0
      const updateHelper = (object: THREE.Object3D, colliding: boolean) => {
        const helper = boundsHelpers[helperIndex++]
        helper.box.setFromObject(object)
        helper.visible = current.showColliders
        ;(helper.material as THREE.LineBasicMaterial).color.set(colliding ? '#ff6257' : '#59d9c6')
      }
      colliderLinks.forEach(({ mesh }) => updateHelper(mesh, hasCollision))
      collisionEntries.forEach(({ object, name }) => updateHelper(object, uniqueCollisions.includes(name)))

      controls.update()
      renderer.render(scene, camera)
      frames++
      if (now - telemetryTime > 250) {
        const fps = Math.round((frames * 1000) / (now - telemetryTime))
        current.onTelemetry({ tip: [tipPosition.x, tipPosition.y, tipPosition.z], fps, held: heldObject })
        telemetryTime = now
        frames = 0
      }
      if (collisionStopped) collisionStopped = false
    }
    animationId = requestAnimationFrame(animate)

    return () => {
      cancelAnimationFrame(animationId)
      observer.disconnect()
      controls.dispose()
      renderer.domElement.removeEventListener('pointerdown', onPointerDown)
      renderer.domElement.removeEventListener('pointerup', onPointerUp)
      scene.traverse((object) => {
        if (object instanceof THREE.Mesh || object instanceof THREE.Sprite) {
          object.geometry?.dispose()
          const materials = Array.isArray(object.material) ? object.material : [object.material]
          materials.forEach((mat) => {
            if (mat instanceof THREE.SpriteMaterial) mat.map?.dispose()
            mat.dispose()
          })
        }
      })
      envTarget.dispose()
      renderer.dispose()
      renderer.domElement.remove()
    }
  }, [])

  return (
    <div className="scene-mount" ref={mountRef}>
      <div className="scene-poster" aria-hidden="true">
        <div className="poster-arm"><span /><span /><span /></div>
        <p>INITIALIZING WORK CELL</p>
      </div>
    </div>
  )
}
