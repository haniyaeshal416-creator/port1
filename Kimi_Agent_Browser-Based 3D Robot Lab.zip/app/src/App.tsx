import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import {
  Activity,
  Box,
  Braces,
  Camera,
  ChevronDown,
  CircleDot,
  Clock3,
  Download,
  Focus,
  Grip,
  Grid3X3,
  Hand,
  HelpCircle,
  Hexagon,
  ListPlus,
  Pause,
  Play,
  Plus,
  Redo2,
  Repeat2,
  RotateCcw,
  ShieldCheck,
  SkipBack,
  SlidersHorizontal,
  Square,
  Trash2,
  TriangleAlert,
  X,
  Zap,
} from 'lucide-react'
import RobotScene from './components/RobotScene'
import {
  HOME_JOINTS,
  INITIAL_OBJECTS,
  JOINTS,
  OBJECT_META,
  PICK_AND_PLACE,
  type Keyframe,
  type ObjectId,
  type ObjectPositions,
  type Telemetry,
  type Vec3,
} from './types/robot'
import './App.css'

const cloneFrames = (frames: Keyframe[]) => frames.map((frame) => ({ ...frame, joints: [...frame.joints] }))
const wrapAngle = (angle: number) => ((angle + 180) % 360 + 360) % 360 - 180
const formatTime = (time: number) => `${String(Math.floor(time / 60)).padStart(2, '0')}:${(time % 60).toFixed(1).padStart(4, '0')}`

const PRESETS: Record<string, Keyframe[]> = {
  pick: PICK_AND_PLACE,
  inspect: [
    { id: 'i0', name: 'Start', time: 0, joints: HOME_JOINTS, gripper: 75 },
    { id: 'i1', name: 'Scan left', time: 3, joints: [-42, -62, 74, 168, 25, -30], gripper: 75 },
    { id: 'i2', name: 'Inspect', time: 6, joints: [0, -82, 92, 170, 90, 60], gripper: 75 },
    { id: 'i3', name: 'Scan right', time: 9, joints: [48, -62, 74, 168, -25, 30], gripper: 75 },
    { id: 'i4', name: 'Return', time: 12, joints: HOME_JOINTS, gripper: 75 },
  ],
  calibration: [
    { id: 'c0', name: 'Zero pose', time: 0, joints: [0, -20, 35, 165, 0, 0], gripper: 85 },
    { id: 'c1', name: 'Axis test', time: 2.5, joints: [60, -55, 70, 165, 90, 90], gripper: 45 },
    { id: 'c2', name: 'Counter rotate', time: 5, joints: [-60, -75, 85, 170, -90, -90], gripper: 85 },
    { id: 'c3', name: 'Reach', time: 8, joints: [0, -105, 65, -140, 0, 180], gripper: 20 },
    { id: 'c4', name: 'Home', time: 12, joints: HOME_JOINTS, gripper: 85 },
  ],
}

function interpolate(frames: Keyframe[], time: number) {
  const sorted = [...frames].sort((a, b) => a.time - b.time)
  if (!sorted.length) return { joints: HOME_JOINTS, gripper: 85 }
  if (time <= sorted[0].time) return { joints: [...sorted[0].joints], gripper: sorted[0].gripper }
  if (time >= sorted[sorted.length - 1].time) return { joints: [...sorted[sorted.length - 1].joints], gripper: sorted[sorted.length - 1].gripper }
  const nextIndex = sorted.findIndex((frame) => frame.time >= time)
  const a = sorted[nextIndex - 1]
  const b = sorted[nextIndex]
  const t = (time - a.time) / (b.time - a.time)
  const eased = t * t * (3 - 2 * t)
  return {
    joints: a.joints.map((value, index) => value + (b.joints[index] - value) * eased),
    gripper: a.gripper + (b.gripper - a.gripper) * eased,
  }
}

export default function App() {
  const [joints, setJoints] = useState<number[]>([...HOME_JOINTS])
  const [gripper, setGripper] = useState(85)
  const [objectPositions, setObjectPositions] = useState<ObjectPositions>({ ...INITIAL_OBJECTS })
  const [selectedObject, setSelectedObject] = useState<ObjectId>('cube')
  const [frames, setFrames] = useState<Keyframe[]>(() => cloneFrames(PICK_AND_PLACE))
  const [selectedFrame, setSelectedFrame] = useState<string | null>(null)
  const [currentTime, setCurrentTime] = useState(0)
  const [isPlaying, setIsPlaying] = useState(false)
  const [loop, setLoop] = useState(true)
  const [speed, setSpeed] = useState(1)
  const [showGrid, setShowGrid] = useState(true)
  const [showColliders, setShowColliders] = useState(false)
  const [safetyStop, setSafetyStop] = useState(true)
  const [collisions, setCollisions] = useState<string[]>([])
  const [view, setView] = useState<'perspective' | 'front' | 'top'>('perspective')
  const [resetViewToken, setResetViewToken] = useState(0)
  const [emergency, setEmergency] = useState(false)
  const [helpOpen, setHelpOpen] = useState(false)
  const [telemetry, setTelemetry] = useState<Telemetry>({ tip: [0, 0, 0], fps: 60, held: null })
  const [events, setEvents] = useState<string[]>(['Work cell initialized', 'Collision monitoring active'])
  const isPlayingRef = useRef(isPlaying)
  const safetyStopRef = useRef(safetyStop)
  isPlayingRef.current = isPlaying
  safetyStopRef.current = safetyStop

  const duration = Math.max(12, ...frames.map((frame) => frame.time))
  const sortedFrames = useMemo(() => [...frames].sort((a, b) => a.time - b.time), [frames])

  const logEvent = useCallback((message: string) => {
    setEvents((previous) => [message, ...previous].slice(0, 4))
  }, [])

  const applyTime = useCallback((time: number, source = frames) => {
    const pose = interpolate(source, time)
    setCurrentTime(time)
    setJoints(pose.joints)
    setGripper(pose.gripper)
  }, [frames])

  useEffect(() => {
    if (!isPlaying || emergency) return
    let raf = 0
    const startedAt = performance.now()
    const from = currentTime >= duration ? 0 : currentTime
    const tick = (now: number) => {
      let next = from + ((now - startedAt) / 1000) * speed
      if (next >= duration) {
        if (loop) next %= duration
        else {
          applyTime(duration)
          setIsPlaying(false)
          logEvent('Sequence complete')
          return
        }
      }
      applyTime(next)
      raf = requestAnimationFrame(tick)
    }
    raf = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(raf)
    // Playback intentionally captures the starting playhead once.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isPlaying, emergency, loop, speed, duration, applyTime, logEvent])

  const handleCollisions = useCallback((names: string[]) => {
    setCollisions(names)
    if (names.length && safetyStopRef.current && isPlayingRef.current) {
      setIsPlaying(false)
      logEvent(`Safety stop: ${names[0]}`)
    }
  }, [logEvent])

  const updateJoint = (index: number, value: number) => {
    setIsPlaying(false)
    setEmergency(false)
    setJoints((previous) => previous.map((joint, i) => i === index ? value : joint))
  }

  const toggleGrip = useCallback(() => {
    setIsPlaying(false)
    setGripper((previous) => previous > 50 ? 18 : 85)
  }, [])

  const resetScene = useCallback(() => {
    setIsPlaying(false)
    setEmergency(false)
    setJoints([...HOME_JOINTS])
    setGripper(85)
    setObjectPositions({ ...INITIAL_OBJECTS })
    setCurrentTime(0)
    setCollisions([])
    setResetViewToken((value) => value + 1)
    logEvent('Work cell reset to home pose')
  }, [logEvent])

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      const target = event.target as HTMLElement
      if (['INPUT', 'SELECT', 'TEXTAREA', 'BUTTON'].includes(target.tagName)) return
      if (event.code === 'Space') {
        event.preventDefault()
        setEmergency(false)
        setIsPlaying((value) => !value)
      }
      if (event.key.toLowerCase() === 'g') toggleGrip()
      if (event.key.toLowerCase() === 'r') resetScene()
      if (event.key === 'Escape') setHelpOpen(false)
    }
    window.addEventListener('keydown', onKeyDown)
    return () => window.removeEventListener('keydown', onKeyDown)
  }, [resetScene, toggleGrip])

  const approachObject = () => {
    const p = objectPositions[selectedObject]
    const radial = Math.hypot(p[0] + 1.9, p[2])
    const dy = p[1] + 0.72 - 1.9
    const l1 = 1.55
    const l2 = 1.25
    const cosine = Math.max(-1, Math.min(1, (radial * radial + dy * dy - l1 * l1 - l2 * l2) / (2 * l1 * l2)))
    const elbow = Math.acos(cosine)
    const theta = Math.atan2(dy, radial) - Math.atan2(l2 * Math.sin(elbow), l1 + l2 * Math.cos(elbow))
    const shoulder = -(90 - theta * 180 / Math.PI)
    const elbowDegrees = elbow * 180 / Math.PI
    const wrist = wrapAngle(-(shoulder + elbowDegrees))
    const yaw = Math.atan2(-p[2], p[0] + 1.9) * 180 / Math.PI
    setIsPlaying(false)
    setEmergency(false)
    setJoints([yaw, Math.max(-110, shoulder), elbowDegrees, wrist, 0, 0])
    setGripper(85)
    logEvent(`Approaching ${OBJECT_META[selectedObject].code}`)
  }

  const nudgeObject = (axis: 0 | 2, amount: number) => {
    setObjectPositions((previous) => {
      const next = { ...previous, [selectedObject]: [...previous[selectedObject]] as Vec3 }
      next[selectedObject][axis] = Math.max(axis === 0 ? -0.2 : -1.55, Math.min(axis === 0 ? 2.3 : 1.55, next[selectedObject][axis] + amount))
      return next
    })
  }

  const loadFrame = (frame: Keyframe) => {
    setIsPlaying(false)
    setSelectedFrame(frame.id)
    applyTime(frame.time)
  }

  const addFrame = () => {
    const id = `frame-${Date.now()}`
    const frame: Keyframe = {
      id,
      name: `Pose ${frames.length + 1}`,
      time: Math.min(currentTime, duration),
      joints: [...joints],
      gripper,
    }
    setFrames((previous) => [...previous.filter((item) => Math.abs(item.time - frame.time) > 0.08), frame])
    setSelectedFrame(id)
    logEvent(`Keyframe captured at ${formatTime(frame.time)}`)
  }

  const deleteFrame = () => {
    if (!selectedFrame) return
    setFrames((previous) => previous.filter((frame) => frame.id !== selectedFrame))
    setSelectedFrame(null)
    logEvent('Keyframe removed')
  }

  const loadPreset = (name: string) => {
    const preset = cloneFrames(PRESETS[name])
    setFrames(preset)
    setSelectedFrame(null)
    setCurrentTime(0)
    setJoints([...preset[0].joints])
    setGripper(preset[0].gripper)
    setIsPlaying(false)
    logEvent(`${name === 'pick' ? 'Pick & place' : name === 'inspect' ? 'Inspection scan' : 'Axis calibration'} loaded`)
  }

  const exportSequence = () => {
    const blob = new Blob([JSON.stringify({ name: 'Kinesis sequence', duration, keyframes: sortedFrames }, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const anchor = document.createElement('a')
    anchor.href = url
    anchor.download = 'kinesis-sequence.json'
    anchor.click()
    URL.revokeObjectURL(url)
    logEvent('Sequence exported as JSON')
  }

  const scrubTimeline = (event: React.PointerEvent<HTMLDivElement>) => {
    const rect = event.currentTarget.getBoundingClientRect()
    const time = Math.max(0, Math.min(duration, ((event.clientX - rect.left) / rect.width) * duration))
    setIsPlaying(false)
    applyTime(time)
  }

  return (
    <div className={`app-shell ${emergency ? 'is-emergency' : ''}`}>
      <header className="topbar">
        <div className="brand">
          <div className="brand-mark" aria-hidden="true"><Hexagon size={24} /><span /></div>
          <div><strong>KINESIS</strong><span>ROBOTICS LAB</span></div>
        </div>
        <div className="project-title"><span>WORK CELL</span><strong>01 / KR–6 MANIPULATOR</strong></div>
        <div className="topbar-actions">
          <div className={`system-state ${collisions.length ? 'warning' : ''}`}><i />{emergency ? 'ESTOP ACTIVE' : collisions.length ? 'COLLISION' : 'SIMULATION ONLINE'}</div>
          <button className="icon-button" onClick={() => setHelpOpen(true)} aria-label="Open help" title="Help and shortcuts"><HelpCircle size={18} /></button>
          <button className="reset-button" onClick={resetScene}><RotateCcw size={15} /> Reset cell</button>
          <button className="estop-button" onClick={() => { setIsPlaying(false); setEmergency(true); logEvent('Emergency stop engaged') }}><Square size={13} fill="currentColor" /> STOP</button>
        </div>
      </header>

      <main className="workspace">
        <aside className="side-panel left-panel">
          <section className="panel-section joints-section">
            <div className="section-heading"><div><SlidersHorizontal size={15} /><h2>Joint control</h2></div><span>6 AXIS</span></div>
            <div className="joint-list">
              {JOINTS.map((joint, index) => (
                <label className="joint-control" key={joint.short}>
                  <span className="joint-index">{joint.short}</span>
                  <span className="joint-name">{joint.label}<small>{joint.axis}-axis</small></span>
                  <output>{joints[index].toFixed(1)}°</output>
                  <input
                    type="range"
                    min={joint.min}
                    max={joint.max}
                    step="0.5"
                    value={joints[index]}
                    onChange={(event) => updateJoint(index, Number(event.target.value))}
                    aria-label={`${joint.label} angle`}
                    style={{ '--range-progress': `${((joints[index] - joint.min) / (joint.max - joint.min)) * 100}%` } as React.CSSProperties}
                  />
                </label>
              ))}
            </div>
            <div className="gripper-control">
              <div className="gripper-heading"><span><Grip size={15} /> Gripper aperture</span><output>{gripper.toFixed(0)}%</output></div>
              <input type="range" min="0" max="100" value={gripper} onChange={(event) => { setIsPlaying(false); setGripper(Number(event.target.value)) }} aria-label="Gripper aperture" style={{ '--range-progress': `${gripper}%` } as React.CSSProperties} />
              <button className="secondary-button full-width" onClick={toggleGrip}><Hand size={15} />{gripper > 50 ? 'Close gripper' : 'Open gripper'}<kbd>G</kbd></button>
            </div>
          </section>

          <section className="panel-section objects-section">
            <div className="section-heading"><div><Box size={15} /><h2>Work objects</h2></div><span>03</span></div>
            <div className="object-list">
              {(Object.keys(OBJECT_META) as ObjectId[]).map((id) => (
                <button key={id} className={`object-row ${selectedObject === id ? 'selected' : ''}`} onClick={() => setSelectedObject(id)}>
                  <i style={{ background: OBJECT_META[id].color }} />
                  <span><strong>{OBJECT_META[id].name}</strong><small>{OBJECT_META[id].code}{telemetry.held === id ? ' · HELD' : ''}</small></span>
                  <Focus size={14} />
                </button>
              ))}
            </div>
            <div className="object-position">
              <span>POSITION</span><code>X {objectPositions[selectedObject][0].toFixed(2)} &nbsp; Z {objectPositions[selectedObject][2].toFixed(2)}</code>
              <div className="nudge-grid">
                <button onClick={() => nudgeObject(2, 0.15)} aria-label="Move object forward">Z+</button>
                <button onClick={() => nudgeObject(0, -0.15)} aria-label="Move object left">X−</button>
                <button onClick={() => nudgeObject(0, 0.15)} aria-label="Move object right">X+</button>
                <button onClick={() => nudgeObject(2, -0.15)} aria-label="Move object backward">Z−</button>
              </div>
            </div>
            <button className="primary-button full-width" onClick={approachObject}><Focus size={16} /> Approach selected</button>
          </section>
        </aside>

        <section className="viewport-panel">
          <RobotScene
            joints={joints}
            gripper={gripper}
            objectPositions={objectPositions}
            selectedObject={selectedObject}
            showGrid={showGrid}
            showColliders={showColliders}
            view={view}
            resetViewToken={resetViewToken}
            onSelectObject={setSelectedObject}
            onTelemetry={setTelemetry}
            onCollisions={handleCollisions}
            onObjectRelease={(id, position) => { setObjectPositions((previous) => ({ ...previous, [id]: position })); logEvent(`${OBJECT_META[id].code} released`) }}
          />
          <div className="viewport-toolbar">
            <div className="toolbar-group">
              <button className={view === 'perspective' ? 'active' : ''} onClick={() => setView('perspective')} title="Perspective view"><Box size={16} /><span>Orbit</span></button>
              <button className={view === 'front' ? 'active' : ''} onClick={() => setView('front')} title="Front view"><Camera size={16} /><span>Front</span></button>
              <button className={view === 'top' ? 'active' : ''} onClick={() => setView('top')} title="Top view"><Grid3X3 size={16} /><span>Top</span></button>
            </div>
            <div className="toolbar-group compact">
              <button className={showGrid ? 'active' : ''} onClick={() => setShowGrid((value) => !value)} aria-label="Toggle grid" title="Toggle grid"><Grid3X3 size={16} /></button>
              <button className={showColliders ? 'active' : ''} onClick={() => setShowColliders((value) => !value)} aria-label="Toggle collision bounds" title="Collision bounds"><Braces size={16} /></button>
              <button onClick={() => setResetViewToken((value) => value + 1)} aria-label="Reset camera" title="Reset camera"><Redo2 size={16} /></button>
            </div>
          </div>
          <div className="viewport-label"><span>KR–6</span><small>PAYLOAD 6 KG · REACH 1.8 M</small></div>
          <div className="selection-chip"><CircleDot size={13} /><span>{OBJECT_META[selectedObject].code}</span><strong>{telemetry.held === selectedObject ? 'GRIPPED' : 'SELECTED'}</strong></div>
          <div className="telemetry-strip">
            <div><span>TOOL X</span><strong>{telemetry.tip[0].toFixed(2)}<small> m</small></strong></div>
            <div><span>TOOL Y</span><strong>{telemetry.tip[1].toFixed(2)}<small> m</small></strong></div>
            <div><span>TOOL Z</span><strong>{telemetry.tip[2].toFixed(2)}<small> m</small></strong></div>
            <div><span>RENDERER</span><strong>ACTIVE<small> / WebGL</small></strong></div>
          </div>
          {collisions.length > 0 && <div className="collision-banner"><TriangleAlert size={16} /><span>Collision detected</span><strong>{collisions[0]}</strong></div>}
          {emergency && <div className="emergency-overlay"><Square size={22} fill="currentColor" /><strong>EMERGENCY STOP</strong><span>Motion command suspended</span><button onClick={resetScene}>Reset work cell</button></div>}
        </section>

        <aside className="side-panel right-panel">
          <section className="panel-section program-section">
            <div className="section-heading"><div><Zap size={15} /><h2>Sequence</h2></div><button className="bare-icon" onClick={exportSequence} title="Export sequence" aria-label="Export sequence"><Download size={15} /></button></div>
            <label className="preset-select"><span>PROGRAM PRESET</span><div><select defaultValue="pick" onChange={(event) => loadPreset(event.target.value)} aria-label="Load program preset"><option value="pick">Pick & place</option><option value="inspect">Inspection scan</option><option value="calibration">Axis calibration</option></select><ChevronDown size={14} /></div></label>
            <div className="sequence-summary"><span>{frames.length} KEYFRAMES</span><span>{duration.toFixed(1)} SEC</span></div>
            <div className="sequence-list">
              {sortedFrames.map((frame, index) => (
                <button className={`sequence-row ${selectedFrame === frame.id ? 'selected' : ''}`} key={frame.id} onClick={() => loadFrame(frame)}>
                  <span className="sequence-number">{String(index + 1).padStart(2, '0')}</span>
                  <span><strong>{frame.name}</strong><small>{frame.gripper < 50 ? 'Gripper closed' : 'Gripper open'}</small></span>
                  <code>{frame.time.toFixed(1)}s</code>
                  <Play size={12} />
                </button>
              ))}
            </div>
            <button className="secondary-button full-width" onClick={addFrame}><ListPlus size={15} /> Capture current pose</button>
          </section>

          <section className="panel-section safety-section">
            <div className="section-heading"><div><ShieldCheck size={15} /><h2>Safety monitor</h2></div><span className={collisions.length ? 'status-bad' : 'status-good'}>{collisions.length ? 'ALERT' : 'CLEAR'}</span></div>
            <label className="toggle-row"><span><strong>Collision stop</strong><small>Pause sequence on contact</small></span><input type="checkbox" checked={safetyStop} onChange={(event) => setSafetyStop(event.target.checked)} /><i /></label>
            <label className="toggle-row"><span><strong>Collider bounds</strong><small>Visualize detection volumes</small></span><input type="checkbox" checked={showColliders} onChange={(event) => setShowColliders(event.target.checked)} /><i /></label>
            <div className="event-log">
              <div><Activity size={13} /><span>EVENT LOG</span></div>
              {events.map((event, index) => <p key={`${event}-${index}`}><i />{event}</p>)}
            </div>
          </section>
        </aside>

        <section className="timeline-panel">
          <div className="timeline-topline">
            <div className="timeline-title"><Clock3 size={15} /><h2>Motion timeline</h2><span>KEYFRAME ANIMATION</span></div>
            <div className="transport-controls">
              <button onClick={() => { setIsPlaying(false); applyTime(0) }} aria-label="Go to start" title="Go to start"><SkipBack size={16} /></button>
              <button className="play-button" onClick={() => { setEmergency(false); setIsPlaying((value) => !value) }} aria-label={isPlaying ? 'Pause sequence' : 'Play sequence'}>{isPlaying ? <Pause size={16} fill="currentColor" /> : <Play size={16} fill="currentColor" />}{isPlaying ? 'Pause' : 'Run sequence'}</button>
              <button onClick={() => { setIsPlaying(false); applyTime(0) }} aria-label="Stop sequence" title="Stop"><Square size={14} /></button>
              <button className={loop ? 'active' : ''} onClick={() => setLoop((value) => !value)} aria-label="Toggle loop" title="Loop"><Repeat2 size={16} /></button>
            </div>
            <div className="timeline-settings">
              <label>SPEED<select value={speed} onChange={(event) => setSpeed(Number(event.target.value))}><option value="0.5">0.5×</option><option value="1">1.0×</option><option value="1.5">1.5×</option><option value="2">2.0×</option></select></label>
              <button onClick={addFrame}><Plus size={14} /> Keyframe</button>
              <button onClick={deleteFrame} disabled={!selectedFrame} aria-label="Delete selected keyframe" title="Delete selected keyframe"><Trash2 size={14} /></button>
              <code>{formatTime(currentTime)}</code>
            </div>
          </div>
          <div className="timeline-body">
            <div className="track-labels"><span>ROBOT POSE</span><span>GRIPPER</span></div>
            <div className="timeline-track-wrap">
              <div className="timeline-ruler">{Array.from({ length: Math.floor(duration) + 1 }, (_, index) => <span key={index} style={{ left: `${(index / duration) * 100}%` }}>{index % 2 === 0 ? `${index}s` : ''}</span>)}</div>
              <div className="timeline-track" onPointerDown={scrubTimeline}>
                <div className="track-segments">{sortedFrames.slice(1).map((frame) => <i key={frame.id} style={{ left: `${(frame.time / duration) * 100}%` }} />)}</div>
                {sortedFrames.map((frame) => (
                  <button
                    className={`keyframe-marker ${selectedFrame === frame.id ? 'selected' : ''}`}
                    key={frame.id}
                    style={{ left: `${(frame.time / duration) * 100}%` }}
                    onPointerDown={(event) => event.stopPropagation()}
                    onClick={() => loadFrame(frame)}
                    title={`${frame.name} · ${frame.time.toFixed(1)}s`}
                    aria-label={`Load ${frame.name} keyframe`}
                  ><span>{frame.name}</span></button>
                ))}
                <div className="playhead" style={{ left: `${(currentTime / duration) * 100}%` }}><i /></div>
              </div>
              <div className="gripper-track">{sortedFrames.map((frame) => <i key={frame.id} className={frame.gripper < 50 ? 'closed' : ''} style={{ left: `${(frame.time / duration) * 100}%` }} />)}</div>
            </div>
          </div>
        </section>
      </main>

      {helpOpen && (
        <div className="modal-backdrop" onClick={() => setHelpOpen(false)}>
          <section className="help-modal" role="dialog" aria-modal="true" aria-labelledby="help-title" onClick={(event) => event.stopPropagation()}>
            <button className="modal-close" onClick={() => setHelpOpen(false)} aria-label="Close help"><X size={18} /></button>
            <span className="modal-kicker">OPERATOR MANUAL / 01</span>
            <h2 id="help-title">Control the work cell</h2>
            <p>Pose the arm with joint sliders, select a part in the viewport, then use <strong>Approach selected</strong>. Close the gripper near the part to pick it up; open it to release.</p>
            <div className="help-steps"><div><span>01</span><p><strong>Pose & approach</strong>Drag to orbit, scroll to zoom, or tune each joint directly.</p></div><div><span>02</span><p><strong>Capture motion</strong>Move the playhead, pose the arm, then capture a keyframe.</p></div><div><span>03</span><p><strong>Run safely</strong>Play the sequence and watch collision feedback in real time.</p></div></div>
            <div className="shortcut-list"><span><kbd>Space</kbd> Play / pause</span><span><kbd>G</kbd> Toggle gripper</span><span><kbd>R</kbd> Reset cell</span></div>
            <button className="primary-button full-width" onClick={() => setHelpOpen(false)}>Return to work cell</button>
          </section>
        </div>
      )}
    </div>
  )
}
